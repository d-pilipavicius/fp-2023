module Code where 

import Lib2(forTestingFiles)

function :: String -> String
function = forTestingFiles

main :: IO ()
main = do
    lines <- fmap lines $ readFile "a_1/execute.txt"
    mapM_ (\(num, line) -> do
            let output = function line
            writeFile ("a_1/executed" ++ show num ++ ".txt") $ "Input: " ++ line ++ "\n" ++ output
          ) (zip [1..] lines)