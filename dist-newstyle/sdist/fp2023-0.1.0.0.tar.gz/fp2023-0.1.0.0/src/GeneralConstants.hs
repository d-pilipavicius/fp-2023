module GeneralConstants where

_TIME_COLUMN_NAME :: String
_TIME_COLUMN_NAME = "CURRENT_TIME"

_TIME_INSERT_VALUE :: String
_TIME_INSERT_VALUE = "insert.time.now()"